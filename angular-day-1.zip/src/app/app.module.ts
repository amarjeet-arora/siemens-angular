import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainappComponent } from './mainapp/mainapp.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { UserService } from './shared/user.service';
import { DepartmentService } from './shared/dept.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NumberComponent } from './number/number.component';
import { TemplateComponent } from './template/template.component'
import { TemplateService } from './shared/template.service';
import { DatadrivenComponent } from './datadriven/datadriven.component';
import { HttpClientModule } from '@angular/common/http'
@NgModule({
  // components,pipes and directives
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
    NumberComponent,
    TemplateComponent,
    DatadrivenComponent
  ],
  //modules
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule
  ],
  // contains services
  providers: [UserService,DepartmentService,TemplateService],
  bootstrap: [AppComponent]
})
export class AppModule { }
