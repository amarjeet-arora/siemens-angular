import { Component, OnInit, Input } from '@angular/core';
import { UserService } from '../shared/user.service';
import { DepartmentService } from '../shared/dept.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input()
  userdata="user details"
  userdetails:any
  dsa:any

  constructor(private us:UserService,private ds:DepartmentService) {
   this.dsa=this.ds.loadDept()
   this.userdetails= this.us.loadUsers()
   }

   applyStyle(country:any){
     switch(country) {
       case 'UK' :
         return "green"
         case 'USA' :
         return "blue"
         case 'INDIA' :
         return "purple"
         default:
          return null
     }


   }


   users:any=[
     {
       "name":"User-1",
       "country": "UK"
     },
     {
      "name":"User-2",
      "country": "INDIA"
    },
    {
      "name":"User-3",
      "country": "USA"
    }
   ]
  ngOnInit(): void {
  }

}
