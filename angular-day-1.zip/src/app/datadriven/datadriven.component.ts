import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-datadriven',
  templateUrl: './datadriven.component.html',
  styleUrls: ['./datadriven.component.css']
})
export class DatadrivenComponent implements OnInit {

myForm: FormGroup
uname:FormControl
pass:FormControl
email:FormControl
city:FormControl

createForm(){
  this.myForm=new FormGroup({
    uname:this.uname,
    pass:this.pass,
    email:this.email,
    city:this.city
  })
}
createFormControls(){
  this.uname=new FormControl('',Validators.required)
  this.pass=new FormControl('',[Validators.required,Validators.minLength(6)])
  this.email=new FormControl('',[Validators.required,Validators.email,this.emailValidator])
  this.city=new FormControl('')
}


  constructor() { }

  ngOnInit(): void {
    this.createFormControls()
    this.createForm()
  }
addUser() {
  console.log('user is added',this.myForm.value);

}

emailValidator(control:FormControl){
  let email= control.value
  if(email && email.indexOf('@') !=-1){
    let[_,domain]=email.split('@')
    if(domain !=='siemens.com'){
      return  {
        emailDomain:{
          parsedDomain:domain
        }
      }
    }
  }
  return null
}

}
