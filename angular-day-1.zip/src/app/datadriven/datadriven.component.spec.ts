import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatadrivenComponent } from './datadriven.component';

describe('DatadrivenComponent', () => {
  let component: DatadrivenComponent;
  let fixture: ComponentFixture<DatadrivenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatadrivenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DatadrivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
