import { Component, OnInit, ViewChild } from '@angular/core';
import { NumberComponent } from '../number/number.component';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html',
  styleUrls: ['./mainapp.component.css']
})
export class MainappComponent implements OnInit {
updatedValue='updated user details'

@ViewChild(NumberComponent)
private nc ={} as NumberComponent

inc(){
  this.nc.increment()
}
dec(){
  this.nc.decrement()
}

  constructor() { }

  ngOnInit(): void {
  }

}
