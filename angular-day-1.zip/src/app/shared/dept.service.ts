import { Injectable} from '@angular/core';

@Injectable()
export class DepartmentService {

  loadDept():string[]{
    return ['HR','ADMIN','IT']
  }
}
