import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { response } from 'express';


@Injectable()
export class TemplateService
 {
   constructor(private http:HttpClient){}
   addUserToDB(data:any){
      this.http.post('https://sie-angular-default-rtdb.firebaseio.com/mydata.json',data)
      .subscribe((response)=>{
        console.log(response);

      })

   }
   loadUserFromDB(){
    return this.http.get('https://sie-angular-default-rtdb.firebaseio.com/mydata.json')
   }

 }
