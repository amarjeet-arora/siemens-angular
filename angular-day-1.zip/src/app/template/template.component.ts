import { Component, OnInit } from '@angular/core';
import { TemplateService } from '../shared/template.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {

  users: any[]
  constructor(private ts: TemplateService) { }
  gender = [
    'male',
    'female'
  ]

  ngOnInit(): void {
    this.loadUser()
  }
  addUser(nf: NgForm) {

    this.ts.addUserToDB(nf.value)

  }
  loadUser() {
    this.ts.loadUserFromDB()
      .subscribe(
        data => {
          const myarray = []
          for (let key in data) {
            myarray.push(data[key])

          }
          this.users = myarray
        }
      )
  }

}
